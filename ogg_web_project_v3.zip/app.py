#!/usr/bin/env python3
# v3 minimal to ensure homes visibility and debug pages
import os, json, time, re, shutil, subprocess
from typing import Dict, Any, List, Tuple
from flask import Flask, request, jsonify, Response, make_response
import yaml

APP_TITLE   = "OGG Web Monitor & Control (Local)"
CONFIG_PATH = os.environ.get("OGG_WEB_CONFIG", "/opt/oracle/ogg_web/config/ogg_local.yaml")
LISTEN_HOST = os.environ.get("OGG_WEB_HOST", "0.0.0.0")
LISTEN_PORT = int(os.environ.get("OGG_WEB_PORT", "5000"))
POLL_SECONDS= int(os.environ.get("OGG_POLL_SECONDS", "10"))
DISCOVERY_ROOTS = ["/u01","/u02","/u03","/opt/oracle","/opt/ogg","/opt"]

app = Flask(__name__)

def _json_no_cache(payload, code=200):
    r = make_response(json.dumps(payload), code); r.mimetype="application/json"; r.headers["Cache-Control"]="no-store, no-cache, must-revalidate, max-age=0"; return r

def load_config():
    if not os.path.exists(CONFIG_PATH): raise FileNotFoundError(f"Config not found: {CONFIG_PATH}")
    with open(CONFIG_PATH,"r",encoding="utf-8") as f: data = yaml.safe_load(f) or {}
    if "homes" not in data or not isinstance(data["homes"], list): raise ValueError("config must contain a 'homes' list")
    return data

def discover_homes(max_hits=6):
    homes=[]; 
    for p in os.environ.get("PATH","").split(":"):
        exe = os.path.join(p,"ggsci")
        if os.path.isfile(exe) and os.access(exe, os.X_OK):
            gh=os.path.dirname(exe); 
            if all(h.get("gg_home")!=gh for h in homes): homes.append({"name":os.path.basename(gh) or gh,"gg_home":gh})
    for root in DISCOVERY_ROOTS:
        for d, subdirs, files in os.walk(root):
            if (d.count(os.sep)-root.count(os.sep))>4: subdirs[:]=[]; continue
            if "ggsci" in files:
                gh=d; 
                if all(h.get("gg_home")!=gh for h in homes): homes.append({"name":os.path.basename(gh) or gh,"gg_home":gh}); 
                if len(homes)>=max_hits: break
        if len(homes)>=max_hits: break
    return homes

def attach_defaults(homes):
    ORACLE_HOME=os.environ.get("ORACLE_HOME","").rstrip("/"); TNS_ADMIN=os.environ.get("TNS_ADMIN",(ORACLE_HOME+"/network/admin" if ORACLE_HOME else ""))
    out=[]; 
    for h in homes:
        gh=(h.get("gg_home") or "").rstrip("/"); name=h.get("name") or os.path.basename(gh) or gh
        out.append({"name":name,"gg_home":gh,"oracle_home":h.get("oracle_home",ORACLE_HOME),"tns_admin":h.get("tns_admin",TNS_ADMIN),"db_name":h.get("db_name",""),"useridalias":h.get("useridalias",""),"show_lag":h.get("show_lag",False)})
    return out

@app.get("/api/homes")
def api_homes():
    source="config"; err=None; homes=[]
    try:
        cfg=load_config()
        homes=[{"name":h.get("name") or h.get("gg_home"),"gg_home":h.get("gg_home"),"oracle_home":h.get("oracle_home","")} for h in cfg["homes"]]
    except Exception as e:
        source="discovery"; err=str(e); homes=attach_defaults(discover_homes())
    return _json_no_cache({"homes":homes,"source":source,"error":err,"config_path":CONFIG_PATH})

@app.get("/api/debug")
def api_debug():
    info={"config_path":CONFIG_PATH,"exists":os.path.exists(CONFIG_PATH),"time":time.ctime()}
    try:
        with open(CONFIG_PATH,"r",encoding="utf-8") as f: info["config_head"]="".join(f.readlines()[:60])
    except Exception as e: info["config_head_err"]=str(e)
    try:
        cfg=load_config(); info["cfg_homes_count"]=len(cfg.get("homes",[])); info["cfg_homes"]=cfg.get("homes",[])
    except Exception as e: info["cfg_error"]=str(e); info["discovered"]=attach_defaults(discover_homes())
    return _json_no_cache(info)

@app.get("/")
def index():
    html = """<!doctype html><meta charset='utf-8'><title>OGG Homes</title>
    <h3>Homes</h3><div id='homes'></div><pre id='err' style='white-space:pre-wrap;color:#f88'></pre>
    <script>
    async function load(){try{const r=await fetch('/api/homes',{cache:'no-store'}); const d=await r.json();
      if(!d.homes||d.homes.length===0){document.getElementById('err').textContent='No homes. Source='+d.source+'\\nPath: '+(d.config_path||''); return;}
      const div=document.getElementById('homes'); d.homes.forEach(h=>{const e=document.createElement('div'); e.textContent='• '+h.name+' — '+(h.gg_home||''); div.appendChild(e);});
    }catch(e){document.getElementById('err').textContent='Fetch failed: '+e;}}
    load();
    </script>"""
    return Response(html, mimetype="text/html")

if __name__ == "__main__":
    print(f"* OGG Web @ http://{LISTEN_HOST}:{LISTEN_PORT}  config={CONFIG_PATH}")
    try:
        with open(CONFIG_PATH,'r',encoding='utf-8') as f: print('* Config head:\n'+''.join(f.readlines()[:30]))
    except Exception as e: print('* Config read issue:',e)
    app.run(host=LISTEN_HOST, port=LISTEN_PORT)
